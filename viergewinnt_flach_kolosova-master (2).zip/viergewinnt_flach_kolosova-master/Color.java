package Heimaufgabe_Blatt9_Programmierprojekt;
/* beatrix.flach@tu-clausthal.de  
 * Vorname: Beatrix  
 * Nachname: Flach
 * 
 * anna.kolosova@tu-clausthal.de
 * Vorname: Anna
 * Nachname: Kolosova
 */ 
/**
 * @author Bea und Anna
 */

// O Gelb

/** Wegen enum neue Klasse f�r die Farbe. */
public enum Color{RED, YELLOW};
