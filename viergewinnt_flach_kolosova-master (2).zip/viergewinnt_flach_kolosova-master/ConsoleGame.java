package Heimaufgabe_Blatt9_Programmierprojekt;
import java.io.IOException;
import Heimaufgabe_Blatt9_Programmierprojekt.Bord;
/** beatrix.flach@tu-clausthal.de  
 * Vorname: Beatrix  
 * Nachname: Flach
 * 
 * anna.kolosova@tu-clausthal.de
 * Vorname: Anna
 * Nachname: Kolosova
 */ 
/**
 * 
 * @author Anna
 * @author Beatrix
 *Class ConsoleGame - Aufgabe 10(e.)
 */
public class ConsoleGame extends Game {
	public ConsoleGame(Bord Bord1) {
		super(Bord1);
	}
/**Aufgabe 10(e.)
 * @method doGame
 * @param Player1
 * @param Player2
 * In der Methode werden Spieler gespeichert und ein aktueller Spieler ausgew�hlt
 */
public void doGame(Player Player1, Player Player2) {
		Player aktuellerPlayer = Player1;
		while (Bord1.testVictory() == Winner.NONE || Bord1.testVictory() == Winner.TIE) { //das Spiel wird solange ausgef�hrt bis einen Sieger gint
		try {
			aktuellerPlayer.doTurn();
			System.out.print("\n");
		    System.out.println(Bord1.toString());
		    swapPlayer();
		} 
		catch (IOException e) {
		}
        }
		System.out.println("And the Winner is:");
		System.out.println(Bord1.testVictory());
}			
	}
		

