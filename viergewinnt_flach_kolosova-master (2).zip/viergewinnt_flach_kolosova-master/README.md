# VierGewinnt_Flach_Kolosova

Das Spiel Vier Gewinnt für die Konsole für den Programmierkurs im SoSe 2019
Version 3 (Aufgabenblatt 10 Spielablauf)
Programmiert von:
Beatrix Flach
Kolosova Anna