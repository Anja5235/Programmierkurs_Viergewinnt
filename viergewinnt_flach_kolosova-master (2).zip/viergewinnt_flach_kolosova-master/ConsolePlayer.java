package Heimaufgabe_Blatt9_Programmierprojekt;
import java.io.*;
/** beatrix.flach@tu-clausthal.de  
 * Vorname: Beatrix  
 * Nachname: Flach
 * 
 * anna.kolosova@tu-clausthal.de
 * Vorname: Anna
 * Nachname: Kolosova
 */  

/**Vier gewinnt - Aufgabe 10 - Spielablauf
 * 01.07.2019
 * @author Anna
 * @author Beatrix
 * @version 3 (Spielablauf)
 * Class ConsolePlayer erbt von Player (Programmieraufgabe 10(c.))
 */
public class ConsolePlayer extends Player {
	
	public ConsolePlayer(Color newColor, Bord BoardObjekt) { //Hier wird Instanz der Klasse Player erzeugt
		super(newColor, BoardObjekt);
	}
	
	public Color getColor (Player Player1) {
		return Player1.color;
	}
/**Aufgabe 10(c.)
 * Methode doTurn() wird hier implementiert
 * Der Nutzer wird nach seiner Eingabe gefragt. Danach wird entsprechend super.doDrop(input) aufgerufen;
 *@nethod doTurn()
 * @throws IllegalMoveException 
 * @throws ColumnFullException 
 * 
 * 
 */
	public void doTurn(Player Player1, Player Player2) throws IOException {
	BufferedReader consoleReader = new BufferedReader(new InputStreamReader(System.in));	
	int input;
	if (getColor(Player1)==Color.RED) {
	System.out.print("Spieler X, was ist dein n�chster Zug, genauer gesagt, die Spalte?: "); //Der Player wird nach einer Eingabe gefragt
	try {
        input = Integer.parseInt(consoleReader.readLine());
	    super.doDrop(input); 
	}
	catch (NumberFormatException a)
	{
		System.err.println("Ung�ltiges Format der Eingabe, bitte nochmal");
	} 
	catch (ColumnFullException e) {
	}
	catch (IllegalMoveException e) {
	} 
	}
	}

@Override
public void doTurn() throws IOException {
	// TODO Auto-generated method stub
	
}
	}

