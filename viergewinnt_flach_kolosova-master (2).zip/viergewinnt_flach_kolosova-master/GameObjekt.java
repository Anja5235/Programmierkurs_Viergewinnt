package Heimaufgabe_Blatt9_Programmierprojekt;

/** beatrix.flach@tu-clausthal.de  
 * Vorname: Beatrix  
 * Nachname: Flach
 * 
 * anna.kolosova@tu-clausthal.de
 * Vorname: Anna
 * Nachname: Kolosova
 */ 

/**
 * @author Bea und Anna
 */

public abstract class GameObjekt {

	public abstract String toString();

}

