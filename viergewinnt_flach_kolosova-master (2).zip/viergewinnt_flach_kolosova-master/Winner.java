package Heimaufgabe_Blatt9_Programmierprojekt;

/** beatrix.flach@tu-clausthal.de  
 * Vorname: Beatrix  
 * Nachname: Flach
 * 
 * anna.kolosova@tu-clausthal.de
 * Vorname: Anna
 * Nachname: Kolosova
 */  

/**
 * @author Bea und Anna
 */

/** Wegen enum neue Klasse. Der Gewinner. Mit Aufgabe 2(e.) mit einer neuen Kategorie Gleichstand*/
public enum Winner{RED, YELLOW, NONE, TIE};